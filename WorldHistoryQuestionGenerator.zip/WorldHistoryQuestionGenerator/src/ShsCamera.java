//= ShsCamera ==========================================//
//------------------------------------------------------//
//  The ShsCamera class allows developers to pan around //
//  a virtual environment.                              //
//------------------------------------------------------//

public class ShsCamera {

    //region ATTRIBUTES

    private static ShsVector target;
    private static ShsVector offset;
    private static double speed;
    private static final double DEFAULT_SPEED = 0.01;

    //endregion

    //region BASIC METHODS

    public static void initialize() {
        reset();
        speed = DEFAULT_SPEED;
    }

    public static void update() {
        offset.x += (target.x - offset.x) * speed * ShsTime.getScale();
        offset.y += (target.y - offset.y) * speed * ShsTime.getScale();
    }

    //endregion

    //region ACCESSOR METHODS

    public static ShsVector getOffset() {
        return new ShsVector(offset);
    }

    public static double getOffsetX() {
        return ShsCamera.offset.x;
    }

    public static double getOffsetY() {
        return ShsCamera.offset.y;
    }

    public static double getSpeed() { return ShsCamera.speed; }

    //endregion

    //region MUTATOR METHODS

    public static void setSpeed(double speed) {
        if (speed < 0)
            speed = 0;
        if (speed > 1)
            speed = 1;
        ShsCamera.speed = speed;
    }

    public static void setTarget(ShsVector target) {
        ShsCamera.target.x = target.x;
        ShsCamera.target.y = target.y;
    }

    public static void setTarget(double x, double y) {
        ShsCamera.target.x = x;
        ShsCamera.target.y = y;
    }

    public static void setTarget(double xy) {
        ShsCamera.target.x = xy;
        ShsCamera.target.y = xy;
    }

    //endregion

    //region ADJUSTMENT METHODS

    public static void adjustSpeed(double s) {
        ShsCamera.setSpeed(ShsCamera.speed + s);
    }

    public static void adjustTarget(ShsVector v) {
        ShsCamera.target.add(v);
    }

    public static void adjustTarget(double x, double y) {
        ShsCamera.target.x += x;
        ShsCamera.target.y += y;
    }

    public static void adjustTargetX(double x) {
        ShsCamera.target.x += x;
    }

    public static void adjustTargetY(double y) {
        ShsCamera.target.y += y;
    }

    //endregion

    //region MISC. METHODS

    public static void reset() {
        target = new ShsVector();
        offset = new ShsVector();
    }

    public static void snapToTarget() {
        offset.x = target.x;
        offset.y = target.y;
    }

    //endregion

    //region CONVERSION METHODS

    public static ShsVector screenToWorld(ShsVector screen) {
        return new ShsVector(screen.x - ShsGameInfo.SCREEN_WIDTH / 2.0 + ShsCamera.getOffsetX(), screen.y - ShsGameInfo.SCREEN_HEIGHT / 2.0 + ShsCamera.getOffsetY());
    }

    public static ShsVector worldToScreen(ShsVector world) {
        return new ShsVector(world.x + ShsGameInfo.SCREEN_WIDTH / 2.0 - ShsCamera.getOffsetX(), world.y + ShsGameInfo.SCREEN_HEIGHT / 2.0 - ShsCamera.getOffsetY());
    }

    //endregion

}