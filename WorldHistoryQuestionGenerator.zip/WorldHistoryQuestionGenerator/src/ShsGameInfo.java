import java.awt.*;

//= ShsGameInfo ========================================//
//------------------------------------------------------//
//  This class contains a variety of settings which     //
//  developers may change in order to affect the look   //
//  and behavior of their app.                          //
//------------------------------------------------------//

public class ShsGameInfo {

    // THE TITLE STRING APPEARS IN THE TITLE BAR OF YOUR APP
    public static final String TITLE = "AP World History Review";

    // THESE INTEGERS REPRESENT THE STARTING DIMENSIONS OF THE APP'S
    // WINDOW AND ARE UPDATED WHENEVER THE SIZE OF THE APP CHANGES
    public static int SCREEN_WIDTH = 1024;
    public static int SCREEN_HEIGHT = 768;

    // BACKGROUND_COLOR IS THE COLOR WHICH IS
    // DISPLAYED WHENEVER THE APP IS REPAINTED
    public static final Color BACKGROUND_COLOR = new Color(121, 111, 189);

    // SETTING RESIZABLE_WINDOW TO false LOCKS THE DIMENSIONS OF
    // THE WINDOW, PREVENTING IT FROM BEING CHANGED BY THE USER
    public static final boolean RESIZABLE_WINDOW = true;

    // THE FILE INDICATED BY THIS STRING, WHICH MUST BE LOCATED
    // IN THE src/Resources/Images FOLDER, WILL BE DISPLAYED IN
    // THE TOP LEFT CORNER OF THE TITLE BAR DURING RUNTIME
    public static final String ICON = "logo.png";

    // WHEN SET TO false, THE DEBUGGING BOOLEAN PREVENTS
    // MESSAGES SENT TO THE LOG FROM APPEAR IN THE CONSOLE
    public static final boolean DEBUGGING = true;

    // THE OBJECT REFERENCED BY STARTUP_SCENE IS CLONED AND
    // WILL RUN AFTER THE ENGINE'S LOGO HAS BEEN DISPLAYED
    public static final ShsScene STARTUP_SCENE = new TestScene();

    // UPDATE_TIMER CONTROLS HOW QUICKLY THE APP ATTEMPTS TO UPDATE
    public static final double UPDATE_TIMER = 1000.0 / 60.0;

    // WHEN ANTIALIASING IS TURNED ON, SPRITES AND TEXT WILL
    // LOOK BETTER, BUT THE APP MAY RUN A LITTLE SLOWER
    public static ShsAntialias ANTIALIASING = ShsAntialias.TEXT_AND_SPRITES;

    public static String FINAL_UNITS_COVERED = "12";

}