import java.util.ArrayList;
import java.util.Collections;

//= ShsTextDrawable ====================================//
//------------------------------------------------------//
//  The ShsTextDrawable class is a parent to both       //
//  ShsSprite and ShsText, and its primary function is  //
//  to manage the depth of graphical elements on        //
//  screen.                                             //
//------------------------------------------------------//

public class ShsDrawable implements Comparable {

    //region ATTRIBUTES

    private ShsVector position;
    private double depth;
    private boolean visible;
    private boolean pinned;

    private static ArrayList<ShsDrawable> drawable;

    //endregion

    //region CONSTRUCTOR

    public ShsDrawable() {
        depth = 0;
        visible = true;
        position = ShsVector.ZERO();
    }

    //endregion

    //region DRAW METHODS

    public void draw() {
        draw(false);
    }

    public void draw(boolean skip) {
        if (skip) {
            internalDraw();
            return;
        }

        if (drawable == null)
            drawable = new ArrayList();

        drawable.add(this);
    }

    public void internalDraw() {

    }

    public static void drawAll() {

        if (drawable == null)
            return;

        Collections.sort(drawable);
        for (ShsDrawable d : drawable){
            if (d.getVisible())
                d.internalDraw();
        }

        drawable.clear();
    }

    //endregion

    //region ACCESSORS

    public double getDepth() { return depth; }

    public boolean getPinned() { return pinned; }

    public ShsVector getPosition() {
        return new ShsVector(position);
    }

    public double getPositionX() {
        return position.x;
    }

    public double getPositionY() {
        return position.y;
    }

    public boolean getVisible() { return visible; }

    //endregion

    //region MUTATORS

    public void setDepth(double depth) {
        if (depth < 0)
            depth = 0;
        if (depth > 1)
            depth = 1;
        this.depth = depth;
    }

    public void setPinned(boolean pinned) {
        this.pinned = pinned;
    }

    public void setPosition(ShsVector v) {
        position.x = v.x;
        position.y = v.y;
    }

    public void setPosition(double x, double y) {
        position.x = x;
        position.y = y;
    }

    public void setPosition(double xy) {
        position.x = xy;
        position.y = xy;
    }

    public void setPositionX(double x) {
        position.x = x;
    }

    public void setPositionY(double y) {
        position.y = y;
    }

    public void setVisible(boolean visible) { this.visible = visible; }

    //endregion

    //region ADJUSTMENT METHODS

    public void adjustDepth(double depth) { setDepth(this.depth + depth); }

    public void adjustPosition(ShsVector v) {
        position.x += v.x;
        position.y += v.y;
    }

    public void adjustPosition(double x, double y) {
        position.x += x;
        position.y += y;
    }

    public void adjustPositionX(double x) {
        position.x += x;
    }

    public void adjustPositionY(double y) {
        position.y += y;
    }

    //endregion

    //region OVERRIDE METHODS

    @Override
    public int compareTo(Object o) {

        if (this.getDepth() < ((ShsDrawable)o).getDepth()) {
            return -1;
        }
        else if (this.getDepth() > ((ShsDrawable)o).getDepth()) {
            return 1;
        }
        else {
            return 0;
        }

    }

    //endregion

}