//= ShsVector ==========================================//
//------------------------------------------------------//
//  ShsVector objects contain a coordinate pair, which  //
//  may be useful for storing vector information (such  //
//  as a position) or scalar information (such as       //
//  speed).  The class provides a variety of static     //
//  and non-static mathematical functions.  Distance    //
//  methods are provided, as well as "pre-constructed"  //
//  vectors which are commonly used.                    //
//------------------------------------------------------//

public class ShsVector {

    //region ATTRIBUTES

    public double x;
    public double y;

    //endregion

    //region CONSTRUCTORS

    public ShsVector() {
        x = 0;
        y = 0;
    }

    public ShsVector(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public ShsVector(double xy) {
        this.x = xy;
        this.y = xy;
    }

    public ShsVector(ShsVector v) {
        this.x = v.x;
        this.y = v.y;
    }

    //endregion

    //region NON-STATIC MATHEMATICAL OPERATIONS

    public void add(ShsVector addend) {
        this.x += addend.x;
        this.y += addend.y;
    }

    public void add(double addendX, double addendY) {
        this.x += addendX;
        this.y += addendY;
    }

    public void subtract(ShsVector subtrahend) {
        this.x -= subtrahend.x;
        this.y -= subtrahend.y;
    }

    public void subtract(double subtrahendX, double subtrahendY) {
        this.x -= subtrahendX;
        this.y -= subtrahendY;
    }

    public void multiply(ShsVector multiplier) {
        this.x *= multiplier.x;
        this.y *= multiplier.y;
    }

    public void multiply(double multiplierX, double multiplierY) {
        this.x *= multiplierX;
        this.y *= multiplierY;
    }

    public void divide(ShsVector denominator) {
        this.x /= denominator.x;
        this.y /= denominator.y;
    }

    public void divide(double denominatorX, double denominatorY) {
        this.x /= denominatorX;
        this.y /= denominatorY;
    }

    //endregion

    //region STATIC MATHEMATICAL OPERATIONS

    public static ShsVector add(ShsVector addend1, ShsVector addend2) {
        return new ShsVector(addend1.x + addend2.x, addend1.y + addend2.y);
    }

    public static ShsVector subtract(ShsVector minuend, ShsVector subtrahend) {
        return new ShsVector(minuend.x - subtrahend.x, minuend.y - subtrahend.y);
    }

    public static ShsVector multiply(ShsVector multiplicand, ShsVector multiplier) {
        return new ShsVector(multiplicand.x * multiplier.x, multiplicand.y * multiplier.y);
    }
    
    public static ShsVector divide(ShsVector numerator, ShsVector denominator) {
        return new ShsVector(numerator.x / denominator.x, numerator.y / denominator.y);
    }

    //endregion

    //region DISTANCE METHODS

    public double distance(ShsVector v) {
        return ShsVector.distance(this, v);
    }

    public static double distance(ShsVector v1, ShsVector v2) {
        return Math.sqrt(Math.pow(v1.x - v2.x, 2) + Math.pow(v1.y - v2.y, 2));
    }

    //endregion

    // region PRE-MADE VECTORS

    public static ShsVector ZERO() {
        return new ShsVector(0, 0);
    }

    public static ShsVector QUARTER() { return new ShsVector(0.25, 0.25); }

    public static ShsVector HALF() { return new ShsVector(0.5, 0.5); }

    public static ShsVector UNIT() {
        return new ShsVector(1, 1);
    }

    public static ShsVector DOUBLE() { return new ShsVector(2, 2); }

    public static ShsVector SCREEN_DIMENSIONS() { return new ShsVector(ShsGameInfo.SCREEN_WIDTH, ShsGameInfo.SCREEN_HEIGHT); }

    public static ShsVector SCREEN_CENTER() { return new ShsVector(ShsGameInfo.SCREEN_WIDTH / 2, ShsGameInfo.SCREEN_HEIGHT / 2); }

    //endregion

    //region OBJECT OVERRIDES

    public String toString() {
        return "(" + (int)this.x + ", " + (int)this.y + ")";
    }

    public boolean equals(ShsVector v) {
        return (this.x == v.x && this.y == v.y);
    }

    //endregion

}