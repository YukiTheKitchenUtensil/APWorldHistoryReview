import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;

//= ShsSprite ==========================================//
//------------------------------------------------------//
//  This important class allows developers to load,     //
//  manipulate, and display images.                     //
//------------------------------------------------------//

public class ShsSprite extends ShsDrawable {

    //region NON-STATIC ATTRIBUTES

    private String filename;
    private Image[] image;
    private ShsVector scale;
    private ShsVector origin;
    private int current_frame;
    private int frame_count;
    private double alpha;
    private double rotation;

    //endregion

    //region CONSTRUCTORS

    private ShsSprite() {

    }

    public ShsSprite(String file) {
        this(file, ".png");
    }

    public ShsSprite(String file, String extension) {
        image = new Image[1];
        image[0] = (new ImageIcon("src/Resources/Images/" + file + extension)).getImage();
        setStartingValues(file, 1);
    }

    public ShsSprite(String file, int frame_count) {
        this(file, ".png", frame_count);
    }

    public ShsSprite(String file, String extension, int frame_count) {
        image = new Image[frame_count];
        for (int i = 0; i < frame_count; i++) {
            image[i] = (new ImageIcon("src/Resources/Images/" + file + "-" + i + extension)).getImage();
        }
        setStartingValues(file, frame_count);
    }

    //endregion

    //region BASIC METHODS

    @Override
    public void internalDraw() {

        if (alpha == 0)
            return;

        if (!getVisible())
            return;

        // ANTIALIASING
        if (ShsGameInfo.ANTIALIASING == ShsAntialias.SPRITES_ONLY ||
            ShsGameInfo.ANTIALIASING == ShsAntialias.TEXT_AND_SPRITES) {
            ShsPanel.graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        }
        else {
            ShsPanel.graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        }

        AffineTransform t = new AffineTransform();
        t.setTransform(new AffineTransform());

        t.translate((int)(getPositionX() - (getPinned() ? 0 : -ShsGameInfo.SCREEN_WIDTH / 2.0 + ShsCamera.getOffsetX()) - getWidth() * origin.x * scale.x), (int)(getPositionY() - (getPinned() ? 0 :  -ShsGameInfo.SCREEN_HEIGHT / 2.0 + ShsCamera.getOffsetY()) - getHeight() * origin.y * scale.y));
        t.rotate(Math.toRadians(rotation), getWidth() * origin.x * scale.x, getHeight() * origin.y * scale.y);
        t.scale(scale.x, scale.y);

        ShsPanel.graphics.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float)alpha));
        ShsPanel.graphics.drawImage(image[current_frame], t, ShsPanel.panel);

    }

    //endregion

    //region MISC. METHODS

    private void setStartingValues(String filename, int frame_count) {
        this.filename = filename;
        setPosition(ShsVector.ZERO());
        scale = ShsVector.UNIT();
        origin = ShsVector.ZERO();
        current_frame = 0;
        this.frame_count = frame_count;
        alpha = 1.0f;
        rotation = 0;
    }

    public boolean isPointInside(double x, double y) {

        int left = (int)(getPositionX() - origin.x * getWidth() * scale.x);
        int right = (int)(left + getWidth() * scale.x);
        int top = (int)(getPositionY() - origin.y * getHeight() * scale.y);
        int bottom = (int)(top + getHeight() * scale.y);

        return (x >= left && x <= right && y >= top && y <= bottom);
    }

    public boolean isPointInside(ShsVector point) {
        return isPointInside(point.x, point.y);
    }

    //endregion

    //region ACCESSORS

    public double getAlpha() {
        return alpha;
    }

    public int getCurrentFrame() {
        return current_frame;
    }

    public ShsVector getDimensions() {
        return new ShsVector(getWidth(), getHeight());
    }

    public int getFrameCount() {
        return frame_count;
    }

    public int getHeight() {
        return image[current_frame].getHeight(ShsPanel.panel);
    }

    public ShsVector getOrigin() {
        return new ShsVector(origin);
    }

    public double getOriginX() {
        return origin.x;
    }

    public double getOriginY() {
        return origin.y;
    }

    public double getRotation() { return rotation; }

    public ShsVector getScale() { return new ShsVector(scale); }

    public double getScaleX() {
        return scale.x;
    }

    public double getScaleY() {
        return scale.y;
    }

    public int getWidth() {
        return image[current_frame].getWidth(ShsPanel.panel);
    }

    //endregion

    //region MUTATORS

    public void setAlpha(double alpha) {
        if (alpha < 0)
            alpha = 0;
        if (alpha > 1)
            alpha = 1;
        this.alpha = alpha;
    }

    public void setCurrentFrame(int frame) {
        if (frame < 0)
            frame = 0;
        if (frame >= frame_count)
            frame = frame_count-1;
        this.current_frame = frame;
    }

    public void setOrigin(ShsVector v) {
        origin.x = v.x;
        origin.y = v.y;
    }

    public void setOrigin(double x, double y) {
        origin.x = x;
        origin.y = y;
    }

    public void setOrigin(double xy) {
        origin.x = xy;
        origin.y = xy;
    }

    public void setOriginX(double x) {
        origin.x = x;
    }

    public void setOriginY(double y) {
        origin.y = y;
    }

    public void setRotation(double angle) {
        this.rotation = angle;
    }

    public void setScale(ShsVector v) {
        scale.x = v.x;
        scale.y = v.y;
    }

    public void setScale(double x, double y) {
        scale.x = x;
        scale.y = y;
    }

    public void setScale(double xy) {
        scale.x = xy;
        scale.y = xy;
    }

    public void setScaleX(double x) {
        scale.x = x;
    }

    public void setScaleY(double y) {
        scale.y = y;
    }
    //endregion

    //region ADJUSTMENT METHODS

    public void adjustAlpha(double alpha){
        setAlpha(this.alpha + alpha);
    }

    public void adjustRotation(double angle) {
        setRotation(rotation + angle);
    }

    public void adjustScale(ShsVector v) {
        scale.x += v.x;
        scale.y += v.y;
    }

    public void adjustScale(double x, double y) {
        scale.x += x;
        scale.y += y;
    }

    public void adjustScaleX(double x) {
        scale.x += x;
    }

    public void adjustScaleY(double y) {
        scale.y += y;
    }

    //endregion

    //region OVERRIDE METHODS

    @Override
    public String toString() {
        return filename + " " + getPosition().toString();
    }

    //endregion

}