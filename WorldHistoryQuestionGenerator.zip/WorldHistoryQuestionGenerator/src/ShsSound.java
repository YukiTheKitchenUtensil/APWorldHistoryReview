import javax.sound.sampled.*;
import java.io.*;

//= ShsSound ===========================================//
//------------------------------------------------------//
//  The ShsSound class provides a static method which   //
//  allows developers to play .WAV files (which must    //
//  be located in the src/Resources/Sounds folder).     //
//------------------------------------------------------//

public class ShsSound {

    //region METHODS

    public static void play(String filename) {

        File file = new File("src/Resources/Sounds/" + filename + ".wav");

        try {

            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            Clip clip = AudioSystem.getClip();
            clip.open(stream);
            clip.start();

        } catch (UnsupportedAudioFileException e) {
            ShsLog.write(e.getMessage());
        } catch (IOException e) {
            ShsLog.write(e.getMessage());
        } catch (LineUnavailableException e) {
            ShsLog.write(e.getMessage());
        }

    }

    //endregion

}