import java.io.IOException;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.File;

public class FileConverter {

    public static void convert(String fn, int cf) throws IOException{

        File readFile = new File("src/Resources/Questions/" + fn + ".txt");
        Scanner fileReader = new Scanner(readFile);
        FileWriter fileW = new FileWriter("src/Resources/Questions/Unit" + cf + ".txt");
        String writtenLine = "";
        while (fileReader.hasNextLine()){
            if (fileReader.nextLine().equals("---")){
                writtenLine = "*" + fileReader.nextLine() + "^";
                for (int i = 0; i < QuestionBank.ANSWER_LETTERS.length(); i++){
                    writtenLine += fileReader.nextLine();
                }
                writtenLine += ";" + fileReader.nextLine() + "/";
                fileW.write(writtenLine);
            }
            fileW.write(System.getProperty("line.separator"));
        }
        fileW.close();
        fileReader.close();
    }
}
