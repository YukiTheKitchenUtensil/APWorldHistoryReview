import java.util.ArrayList;

//= ShsScene ===========================================//
//------------------------------------------------------//
//  A scene represents a specific "moment" within the   //
//  game or simulation, such as a menu, a level, or a   //
//  cut-scene.  All scenes should inherit from ShsScene //
//  and override its initialize, update, draw, and      //
//  cleanup methods.                                    //
//------------------------------------------------------//

public class ShsScene implements Cloneable {

    //region STATIC ATTRIBUTES

    private static ArrayList<ShsScene> sceneList;
    private static ShsSprite black;

    //endregion

    //region NON-STATIC ATTRIBUTES

    private ShsSceneState state = ShsSceneState.FADING_IN;
    private ShsScene next = null;

    //endregion

    //region STATIC METHODS

    public static void start() {
        sceneList = new ArrayList<ShsScene>();

        black = new ShsSprite("black");
        black.setOrigin(0,0);
        black.setScale(ShsGameInfo.SCREEN_WIDTH, ShsGameInfo.SCREEN_HEIGHT);
        black.setPosition(0,0);
        black.setAlpha(1);
        black.setPinned(true);

        ShsCamera.initialize();
    }

    public static void updateAll() {

        // ONLY THE TOP SCENE GETS UPDATED
        if (sceneList.size() > 0) {
            sceneList.get(sceneList.size() - 1).update();
        }

        // REMOVE ALL DEAD SCENES
        for (int i = sceneList.size()-1; i >= 0; i--) {
            if (sceneList.get(i).getState() == ShsSceneState.FINISHED) {
                sceneList.get(i).cleanup();
                if (sceneList.get(i).next != null) {
                    add(sceneList.get(i).next);
                }
                sceneList.remove(i);
                System.gc();
            }
        }

        // NO SCENES? BOUNCE.
        if (sceneList.size() == 0) {
            System.exit(0);
        }

        // ADJUST FADE SCALE
        black.setScale(ShsGameInfo.SCREEN_WIDTH, ShsGameInfo.SCREEN_HEIGHT);

        // ADJUST FADE TRANSPARENCY
        if (sceneList.get(sceneList.size()-1).getState() == ShsSceneState.FADING_OUT) {
            black.setAlpha(black.getAlpha() + (1.0f - black.getAlpha()) * 0.2f * (float)ShsTime.getScale());
            if (black.getAlpha() > 0.99f) {
                black.setAlpha(1);
                sceneList.get(sceneList.size()-1).setState(ShsSceneState.FINISHED);
            }
        }
        else if (sceneList.get(sceneList.size()-1).getState() == ShsSceneState.FADING_IN) {
            black.setAlpha(black.getAlpha() + (0.0f - black.getAlpha()) * 0.2f * (float)ShsTime.getScale());
            if (black.getAlpha() < 0.01f) {
                black.setAlpha(0);
                sceneList.get(sceneList.size()-1).setState(ShsSceneState.IDLE);
            }
        }
    }

    public static void drawAll() {
        for (ShsScene scene : sceneList) {
            scene.draw();
            ShsDrawable.drawAll();
        }

        black.draw(true);
    }

    public static void add(ShsScene scene) {
        ShsCamera.reset();
        scene.initialize();
        scene.setState(ShsSceneState.FADING_IN);
        sceneList.add(scene);
    }

    //endregion

    //region BASIC METHODS

    public void initialize() {

    }

    public void update() {

    }

    public void draw() {

    }

    public void cleanup() {

    }

    //endregion

    //region ACCESSORS

    public ShsSceneState getState() {
        return state;
    }

    //endregion

    //region MUTATORS

    public void setState(ShsSceneState state) {
        this.state = state;
    }

    public void setNext(ShsScene scene) {
        this.next = scene;
    }

    //endregion

    //region OVERRIDES

    public Object clone()
    {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }

    //endregion

}