import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

//= Main ===============================================//
//------------------------------------------------------//
//  This class and its lone method act as an entry      //
//  point for your application, and assists in          //
//  launching the ShsEngine.                            //
//------------------------------------------------------//

public class Main {

    public static void main(String[] args) throws IOException {

        // CREATE AND RUN THE MAIN WINDOW
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ShsWindow();
                ShsScene.start();
                ShsScene.add(new ShsLogo());
            }
        });
        for (int i = 0; i < ShsGameInfo.FINAL_UNITS_COVERED.length(); i++){
            FileConverter.convert("Unit" + ShsGameInfo.FINAL_UNITS_COVERED.substring(i, i+1) + "Bank", Integer.valueOf(ShsGameInfo.FINAL_UNITS_COVERED.substring(i, i+1)));
        }
    }
}