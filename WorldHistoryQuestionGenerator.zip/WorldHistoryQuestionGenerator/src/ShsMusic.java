import javax.sound.sampled.*;
import java.io.*;

//= ShsMusic ===========================================//
//------------------------------------------------------//
//  This class allows developers to load, play, and     //
//  stop audio files.  Support also exists for looping  //
//  a track.  At the moment, only .WAV files are        //
//  supported.                                          //
//------------------------------------------------------//

public class ShsMusic {

    //region ATTRIBUTES

    private Clip clip;

    //endregion

    //region CONSTRUCTORS

    private ShsMusic() {

    }

    public ShsMusic(String filename) {

        File file = new File("src/Resources/Music/" + filename + ".wav");

        try {

            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            clip = AudioSystem.getClip();
            clip.open(stream);

        } catch (UnsupportedAudioFileException e) {
            fail(e.getMessage());
        } catch (IOException e) {
            fail(e.getMessage());
        } catch (LineUnavailableException e) {
            fail(e.getMessage());
        }

    }

    //endregion

    //region BASIC METHODS

    public void play() {
        play(true);
    }

    public void play(boolean loop) {
        if (clip == null)
            return;

        clip.loop(loop ? -1 : 0);
        clip.start();
    }

    public void stop() {
        if (clip == null)
            return;

        clip.stop();
    }

    private void fail(String message) {
        ShsLog.write(message);
        clip = null;
    }

    //endregion

}