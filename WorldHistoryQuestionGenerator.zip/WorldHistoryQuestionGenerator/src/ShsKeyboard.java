//= ShsKeyboard ========================================//
//------------------------------------------------------//
//  This class contains two helpful static methods -    //
//  isDown and isClicked - which report the status of   //
//  various keyboard buttons.                           //
//------------------------------------------------------//

public class ShsKeyboard {

    //region ATTRIBUTES

    private static boolean[] key_current = new boolean[39];
    private static boolean[] key_previous = new boolean[39];

    //endregion

    //region METHODS

    public static void update() {
        for (int i = 0; i < key_current.length; i++) {
            key_previous[i] = key_current[i];
        }
    }


    public static boolean isDown(ShsKey k) {
        if (k == ShsKey._NOTHING)
            return false;
        return key_current[k.ordinal()-1];
    }


    public static boolean isClicked(ShsKey k) {
        if (k == ShsKey._NOTHING)
            return false;
        return key_previous[k.ordinal()-1] && !key_current[k.ordinal()-1];
    }


    public static void setDown(ShsKey k, boolean down) {
        if (k != ShsKey._NOTHING) {
            key_current[k.ordinal() - 1] = down;
        }
    }

    //endregion

    //region HELPER METHODS

    public static ShsKey getShsKeyFromChar(char ch) {

        switch(ch) {

            // UPPER- AND LOWERCASE VERSIONS OF LETTERS
            case 'a':
            case 'A':
                return ShsKey.A;
            case 'b':
            case 'B':
                return ShsKey.B;
            case 'c':
            case 'C':
                return ShsKey.C;
            case 'd':
            case 'D':
                return ShsKey.D;
            case 'e':
            case 'E':
                return ShsKey.E;
            case 'f':
            case 'F':
                return ShsKey.F;
            case 'g':
            case 'G':
                return ShsKey.G;
            case 'h':
            case 'H':
                return ShsKey.H;
            case 'i':
            case 'I':
                return ShsKey.I;
            case 'j':
            case 'J':
                return ShsKey.J;
            case 'k':
            case 'K':
                return ShsKey.K;
            case 'l':
            case 'L':
                return ShsKey.L;
            case 'm':
            case 'M':
                return ShsKey.M;
            case 'n':
            case 'N':
                return ShsKey.N;
            case 'o':
            case 'O':
                return ShsKey.O;
            case 'p':
            case 'P':
                return ShsKey.P;
            case 'q':
            case 'Q':
                return ShsKey.Q;
            case 'r':
            case 'R':
                return ShsKey.R;
            case 's':
            case 'S':
                return ShsKey.S;
            case 't':
            case 'T':
                return ShsKey.T;
            case 'u':
            case 'U':
                return ShsKey.U;
            case 'v':
            case 'V':
                return ShsKey.V;
            case 'w':
            case 'W':
                return ShsKey.W;
            case 'x':
            case 'X':
                return ShsKey.X;
            case 'y':
            case 'Y':
                return ShsKey.Y;
            case 'z':
            case 'Z':
                return ShsKey.Z;

            // NUMBER ROW
            case '0':
                return ShsKey.NUM_0;
            case '1':
                return ShsKey.NUM_1;
            case '2':
                return ShsKey.NUM_2;
            case '3':
                return ShsKey.NUM_3;
            case '4':
                return ShsKey.NUM_4;
            case '5':
                return ShsKey.NUM_5;
            case '6':
                return ShsKey.NUM_6;
            case '7':
                return ShsKey.NUM_7;
            case '8':
                return ShsKey.NUM_8;
            case '9':
                return ShsKey.NUM_9;

            // SPECIAL KEYS
            case ' ':
                return ShsKey.SPACE;
            case (char)27:
                return ShsKey.ESCAPE;
            case (char)10:
                return ShsKey.ENTER;
        }

        // NOT A KEY WE SUPPORT!
        return ShsKey._NOTHING;
    }

    //endregion

}