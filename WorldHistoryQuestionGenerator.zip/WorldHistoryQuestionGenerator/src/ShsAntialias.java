//= ShsAntialias =======================================//
//------------------------------------------------------//
//  This enumeration provides a list of all the         //
//  antialiasing options available to developers.       //
//------------------------------------------------------//

public enum ShsAntialias {
    _NOTHING,
    TEXT_ONLY,
    SPRITES_ONLY,
    TEXT_AND_SPRITES
}