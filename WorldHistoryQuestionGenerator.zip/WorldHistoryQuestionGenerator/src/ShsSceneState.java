//= ShsSceneState ======================================//
//------------------------------------------------------//
//  This enumeration lists the four different states    //
//  that an ShsScene object can be in.  Note that a     //
//  fifth "non-state" called _NOTHING also exists,      //
//  which acts as an indicator that something has gone  //
//  terribly, terribly wrong.                           //
//------------------------------------------------------//

public enum ShsSceneState {

    _NOTHING,
    FADING_IN,
    IDLE,
    FADING_OUT,
    FINISHED

}