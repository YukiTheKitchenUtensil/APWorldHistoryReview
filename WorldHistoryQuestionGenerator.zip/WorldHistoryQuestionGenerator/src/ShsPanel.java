import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

//= ShsPanel ===========================================//
//------------------------------------------------------//
//  This class is largely responsible for updating the  //
//  ShsEngine, due to its implementation of the         //
//  paintComponent method.  It also listens for mouse   //
//  and keyboard events.                                //
//------------------------------------------------------//

public class ShsPanel extends JPanel implements MouseListener, KeyListener {

    //region STATIC ATTRIBUTES

    public static JPanel panel;
    public static Graphics2D graphics;
    private static boolean leftMouseButton;
    private static boolean rightMouseButton;

    //endregion

    //region NON-STATIC ATTRIBUTES

    private double timer = System.currentTimeMillis();

    //endregion

    //region CONSTRUCTOR

    public ShsPanel() {
        // SET THE DIMENSIONS OF THE PANEL
        setPreferredSize(new Dimension(ShsGameInfo.SCREEN_WIDTH, ShsGameInfo.SCREEN_HEIGHT));
        addMouseListener(this);
        addKeyListener(this);
        setFocusable(true);
    }

    //endregion

    //region PAINTCOMPONENT

    public void paintComponent(Graphics graphics) {


        // STORE REFERENCES
        ShsPanel.panel = this;
        ShsPanel.graphics = (Graphics2D)graphics;

        // UPDATE DIMENSIONS
        ShsGameInfo.SCREEN_WIDTH = getWidth();
        ShsGameInfo.SCREEN_HEIGHT = getHeight();

        // SOME THINGS HAPPEN ON A TIMER!
        if (System.currentTimeMillis() - timer >= ShsGameInfo.UPDATE_TIMER && !ShsTime.getPaused()) {

            // UPDATE THE TIMER
            ShsTime.update();

            // RESET THE PANEL
            super.paintComponent(graphics);
            setBackground(ShsGameInfo.BACKGROUND_COLOR);

            // UPDATE THE GAME
            ShsScene.updateAll();

            // UPDATE MOUSE STATES
            ShsMouse.getLeftButton().setDown(leftMouseButton);
            ShsMouse.getRightButton().setDown(rightMouseButton);

            // UPDATE THE KEYBOARD
            ShsKeyboard.update();

            // UPDATE THE CAMERA
            ShsCamera.update();

            // DRAW THE SCENE
            ShsScene.drawAll();

            // UPDATE THE TIMER
            timer = System.currentTimeMillis();
        }



        // TRIGGER THE NEXT PAINT
        repaint();

    }

    //endregion

    //region MOUSELISTENER EVENTS

    public void mousePressed(MouseEvent mouseEvent) {
        switch (mouseEvent.getButton()) {
            case 1:
                leftMouseButton = true;
                break;
            case 3:
                rightMouseButton = true;
                break;
        }
    }

    public void mouseReleased(MouseEvent mouseEvent) {
        switch (mouseEvent.getButton()) {
            case 1:
                leftMouseButton = false;
                break;
            case 3:
                rightMouseButton = false;
                break;
        }
    }

    public void mouseClicked(MouseEvent mouseEvent) {

    }
    public void mouseEntered(MouseEvent mouseEvent) {

    }
    public void mouseExited(MouseEvent mouseEvent) {

    }

    //endregion

    //region KEYLISTENER EVENTS

    public void keyTyped(KeyEvent e) { }
    public void keyPressed(KeyEvent e) { ShsKeyboard.setDown(ShsKeyboard.getShsKeyFromChar(e.getKeyChar()), true); }
    public void keyReleased(KeyEvent e) { ShsKeyboard.setDown(ShsKeyboard.getShsKeyFromChar(e.getKeyChar()), false); }

    //endregion

}