import java.awt.*;
import java.util.ArrayList;

public class TextContained{

    private double length;
    private ArrayList<ShsText> textLines;

    public TextContained() {
        this(0, 0, ShsGameInfo.SCREEN_WIDTH);
    }

    public TextContained(double length){
        this(0, 0, length);
    }

    public TextContained(double x, double y, double length){
        this(x, y, length, ShsText.DEFAULT_FONT);
    }

    public TextContained(String text, double length){
        this(0, 0, text, length);
    }

    public TextContained(double x, double y, String text, double length){
        this(x, y, length, text, ShsText.DEFAULT_FONT, ShsText.DEFAULT_SIZE);
    }

    public TextContained(double x, double y, double length, String font_name) { this(x, y, length, font_name, ShsText.DEFAULT_SIZE); }

    public TextContained(double x, double y, double length, String text, String font_name){
        this(x, y, length, text, font_name, ShsText.DEFAULT_SIZE);
    }

    public TextContained(double x, double y, double length, String font_name, int size) {
        this(x, y, length, "", font_name, size);
    }

    public TextContained(double x, double y, double length, String text, String font_name, int size) {
        textLines = new ArrayList<ShsText>();
        this.length = length;
        double yMod = y;
        String currentString = "";
        int wordStart = 0;
        for (int i = 0; i < text.length(); i++){
            if (text.substring(i, i+1).equals(" ")){ //GRABS ONLY WORDS
                if ((currentString.length() + text.substring(wordStart, i+1).length()) * size > length){ //CAN'T BE LONGER THAN LENGTH - CHECKING TO SEE IF THE WORD ADDED WILL GO OVER LENGTH
                    textLines.add(new ShsText(currentString, font_name, size));
                    textLines.get(textLines.size() - 1).setPosition(x, yMod + 32); //MAKES IT DISPLAY AS A PARAGRAPH INSTEAD OF JUST A BLURB OF STRINGS
                    yMod = textLines.get(textLines.size() - 1).getPositionY();
                    textLines.get(textLines.size() - 1).setDepth(1);
                    textLines.get(textLines.size() - 1).setPinned(true);
                    currentString = "";
                }else{
                    currentString += text.substring(wordStart, i+1);
                    wordStart = i+1;
                }
            }
            if (currentString.length() * size == length){ //PREVENTS THE STRINGS IN THE ARRAYLIST FROM BEING LONGER THAN THE VALUE "LENGTH"
                textLines.add(new ShsText(currentString, font_name, size));
                textLines.get(textLines.size() - 1).setPosition(x, yMod + 32); //MAKES IT DISPLAY AS A PARAGRAPH INSTEAD OF JUST A BLURB OF STRINGS
                yMod = textLines.get(textLines.size() - 1).getPositionY();
                textLines.get(textLines.size() - 1).setDepth(1);
                textLines.get(textLines.size() - 1).setPinned(true);
                currentString = "";
            }
        }
        currentString += text.substring(wordStart); //EXTRA CHARACTERS LEFT OVER
        if (currentString.length() != 0){
            textLines.add(new ShsText(currentString, font_name, size));
            textLines.get(textLines.size() - 1).setPosition(x, yMod + 32); //MAKES IT DISPLAY AS A PARAGRAPH INSTEAD OF JUST A BLURB OF OFFSCREEN STRINGS
            textLines.get(textLines.size() - 1).setDepth(1);
            textLines.get(textLines.size() - 1).setPinned(true);
        }
        //System.out.println(textLines); //TESTING PURPOSES
    }

    public void draw(){
        for(ShsText t : textLines){
            t.draw();
        }
    }

    public double getLength() {
        return length;
    }
}
