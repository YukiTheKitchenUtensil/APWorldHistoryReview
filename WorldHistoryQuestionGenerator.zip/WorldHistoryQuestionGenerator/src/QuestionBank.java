import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class QuestionBank {
    private int unitName;
    private ArrayList<ArrayList<String>> questions;
    private ArrayList<String> answers;
    public static final String ANSWER_LETTERS = "ABCD";
    private int length;

    public QuestionBank(int unitName) {
        this.unitName = unitName;
        questions = new ArrayList<ArrayList<String>>();
        answers = new ArrayList<String>();
        File f;
        try{
            f = new File("src/Resources/Questions/Unit" + this.unitName + ".txt");
            Scanner fileReader = new Scanner(f);
            while(fileReader.hasNextLine()){
                String tempStr = fileReader.nextLine();
                String question = "";
                for (int i = tempStr.indexOf("*") + 1; i < tempStr.indexOf("^"); i++){
                    question += tempStr.substring(i, i+1);
                }

                int index = 0;
                ArrayList<String> answerChoices = new ArrayList<String>();
                String answer = "";
                boolean collectAnswer = true;
                for (int i = tempStr.indexOf(")"); i < tempStr.indexOf(";") + 1; i++){
                    if (tempStr.substring(i, i+1).equals(")")){
                        collectAnswer = true;
                    }else if ((ANSWER_LETTERS.contains(tempStr.substring(i, i+1)) && tempStr.substring(i+1, i+2).equals(")")) || i == tempStr.indexOf(";")){
                        collectAnswer = false;
                        answerChoices.add(answer);
                        answer = "";
                        index++;
                    }else if (collectAnswer){
                        answer += tempStr.substring(i, i+1);
                    }
                }
                answerChoices.add(0, question);
                questions.add(answerChoices);
                answers.add(tempStr.substring(tempStr.indexOf("/") - 1, tempStr.indexOf("/")));
            }
            fileReader.close();
            length = answers.size();
            System.out.println(questions);
            System.out.println(answers);

        }catch (FileNotFoundException e){
            System.exit(-1);
        }
    }

    public int getUnitName() {
        return unitName;
    }

    public int getLength(){
        return length;
    }

    public String getQuestion(int index){
        return questions.get(index).get(0);
    }

    public ArrayList<String> getAnswerChoices(int index){
        ArrayList<String> tempArr = new ArrayList<String>();
        for (int i = 1; i < questions.get(index).size(); i++){
            tempArr.add(questions.get(index).get(i));
        }
        return tempArr;
    }

    public String getRightAnswer(int index){
        return answers.get(index);
    }

    public String getFullRightAnswer(int index){
        return answers.get(index) + ") " + questions.get(index).get(ANSWER_LETTERS.indexOf(answers.get(index)) + 1);
    }
}
