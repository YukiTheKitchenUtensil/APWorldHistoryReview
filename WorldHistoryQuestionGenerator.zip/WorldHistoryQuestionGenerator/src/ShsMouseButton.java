//= ShsMouseButton =====================================//
//------------------------------------------------------//
//  ShsMouseButton objects are utilized by the ShsMouse //
//  class to track the states of the left and right     //
//  mouse buttons.                                      //
//------------------------------------------------------//

public class ShsMouseButton {

    //region ATTRIBUTES

    private boolean down;
    private boolean clicked;

    //endregion

    //region ACCESSORS

    public boolean isDown() {
        return down;
    }

    public boolean isClicked() {
        return clicked;
    }

    //endregion

    //region MUTATORS

    public void setDown(boolean down) {
        clicked = this.down && !down;
        this.down = down;
    }

    //endregion

}