//= ShsLogo ============================================//
//------------------------------------------------------//
//  This class inherits from ShsScene, and is intended  //
//  to display the ShsEngine logo at the start of an    //
//  application.  It fades out after five seconds, or   //
//  when the user clicks the left mouse button.         //
//------------------------------------------------------//

public class ShsLogo extends ShsScene {

    //region ATTRIBUTES

    private ShsSprite logo;
    private double timer;

    //endregion

    // region OVERRIDE METHODS

    public void initialize() {

        // INSTANTIATE THE LOGO SPRITE AND PREP IT FOR DISPLAY
        logo = new ShsSprite("logo");
        logo.setOrigin(0.5, 0.5);
        logo.setScale(ShsGameInfo.SCREEN_HEIGHT / 720.0, ShsGameInfo.SCREEN_HEIGHT / 720.0);
        logo.setPosition(ShsGameInfo.SCREEN_WIDTH / 2, ShsGameInfo.SCREEN_HEIGHT);
        logo.setPinned(true);

        // DISPLAY THE LOGO FOR FIVE SECONDS
        timer = ShsTime.getTime() + 5000;

    }


    public void update() {

        // RECENTER THE LOGO
        logo.setPositionX(ShsGameInfo.SCREEN_WIDTH / 2);

        // SLIDE THE LOGO UP
        double target = ShsGameInfo.SCREEN_HEIGHT / 2;
        double y = logo.getPositionY();
        logo.setPositionY(y + (target - y) * (0.15 * ShsTime.getScale()));

        // RESCALE THE LOGO
        logo.setScale(ShsGameInfo.SCREEN_HEIGHT / 720.0, ShsGameInfo.SCREEN_HEIGHT / 720.0);

        // CHECK FOR CLICK OR EXPIRED TIME
        if (getState() == ShsSceneState.IDLE) {
            if (ShsMouse.getLeftButton().isClicked() ||
                timer < ShsTime.getTime()) {
                setState(ShsSceneState.FADING_OUT);
            }
        }

        // FINISHED? LOAD THE STARTUP SCENE!
        if (getState() == ShsSceneState.FINISHED) {
            setNext((ShsScene)ShsGameInfo.STARTUP_SCENE.clone());
        }

    }


    public void draw() {

        // DRAW THE LOGO SPRITE
        logo.draw();

    }

    //endregion

}