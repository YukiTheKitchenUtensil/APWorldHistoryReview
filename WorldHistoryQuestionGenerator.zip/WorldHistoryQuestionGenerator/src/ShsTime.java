//= ShsTime ============================================//
//------------------------------------------------------//
//  The ShsTime class provides static methods for       //
//  keeping track of time within an app.                //
//------------------------------------------------------//

public class ShsTime {

    //region ATTRIBUTES

    private static double start = System.currentTimeMillis();
    private static double time = 0;
    private static double last = 0;
    private static double halted = 0;
    private static boolean paused = false;

    //endregion

    //region BASIC METHODS

    public static void update() {
        if ((System.currentTimeMillis() - start) - last >= ShsGameInfo.UPDATE_TIMER) {
            last = time;
            time = (System.currentTimeMillis() - start);
        }
    }

    //endregion

    //region ACCESSOR METHODS

    public static double getTime() {
        return time;
    }

    public static double getElapsedTime() {
        return time - last;
    }

    public static double getScale() {
        return (getElapsedTime() / (1000.0 / 60.0));
    }

    public static boolean getPaused() { return paused; }

    //endregion

    //region MUTATOR METHODS

    public static void setPaused(boolean paused) {

        if (!ShsTime.paused && paused) {
            halted = System.currentTimeMillis();
        }
        else if (ShsTime.paused && !paused) {
            start += (System.currentTimeMillis() - halted);
        }

        ShsTime.paused = paused;
    }

    //endregion

}