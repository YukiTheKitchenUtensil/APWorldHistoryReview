//= TestScene ==========================================//
//------------------------------------------------------//
//  The TestScene class is an example of an ShsScene,   //
//  and is intended to provide developers with sample   //
//  code which demonstrates basic capabilities of the   //
//  engine.                                             //
//------------------------------------------------------//

import java.util.ArrayList;

public class TestScene extends ShsScene {

    //= ATTRIBUTES =====================================//
    //--------------------------------------------------//

    // CREATE SOME TEXT OBJECTS TO
    // STORE ON-SCREEN MESSAGES
    private ShsText unitName;
    private TextContained question;
    private ArrayList<ShsText> options;
    private ShsText score;
    private int scoreCounter;
    private ShsText average;
    private ArrayList<QuestionBank> q;
    private boolean nextQuestion;
    private ShsText feedback;
    private String unit;
    private int questionDrawn;
    private String answer;
    private int totalQuestions;
    private int correctlyAnswered;


    //= INITIALIZE =====================================//
    //--------------------------------------------------//
    //  This method is called one time just before the  //
    //  black overlay begins to fade.  It is a place to //
    //  manage all of your setup code - especially      //
    //  anything time-consuming, like loading images.   //
    //--------------------------------------------------//
    @Override
    public void initialize() {

        // INITIALIZE THE TITLE TEXT - NOTE THAT IT IS
        // PINNED AND HAS A DEPTH OF 1, MEANING IT IS NOT
        // SUBJECT TO THE MOTION OF THE CAMERA AND WILL
        // SIT ABOVE ANY DRAWABLE OBJECT OF A LOWER DEPTH
        unitName = new ShsText();
        unitName.setText("Unit -");
        unitName.setSize(48);
        unitName.setPosition(20, 20);
        unitName.setDepth(1);
        unitName.setPinned(true);

        // INITIALIZE THE TEXT WHICH DISPLAYS INSTRUCTIONS
        question = new TextContained(ShsGameInfo.SCREEN_WIDTH / 4, ShsGameInfo.SCREEN_HEIGHT / 4, ShsGameInfo.SCREEN_WIDTH,"NULL", "Cuprum-Regular", 32);

        // THE SCORE TEXT DEMONSTRATES HOW TO LOAD
        // A CUSTOM FONT, AS WELL AS HOW TO ALIGN
        // TEXT TO THE RIGHT RATHER THAN THE LEFT,
        // WHICH IS THE DEFAULT!
        score = new ShsText("Cuprum-Regular", 24);
        score.setText("Score: 0");
        score.setPosition(ShsGameInfo.SCREEN_WIDTH - 20, 20);
        score.setAlignment(ShsTextAlignment.RIGHT);
        score.setDepth(1);
        score.setPinned(true);

        average = new ShsText();
        average.setPosition(ShsGameInfo.SCREEN_WIDTH - 20, 50);
        average.setAlignment(ShsTextAlignment.RIGHT);
        average.setDepth(1);
        average.setPinned(true);

        feedback = new ShsText();
        feedback.setPosition(ShsGameInfo.SCREEN_WIDTH / 2, ShsGameInfo.SCREEN_HEIGHT - 32);
        feedback.setAlignment(ShsTextAlignment.CENTERED);
        feedback.setColor(200, 25, 25);
        feedback.setDepth(1);
        feedback.setPinned(true);

        options = new ArrayList<ShsText>(){
            {
                add(new ShsText("Cuprum-Regular", 24));
                add(new ShsText("Cuprum-Regular", 24));
                add(new ShsText("Cuprum-Regular", 24));
                add(new ShsText("Cuprum-Regular", 24));
            }
        };

        for (ShsText option : options){
            option.setText("NULL");
            option.setPosition(ShsGameInfo.SCREEN_WIDTH / 32, ShsGameInfo.SCREEN_HEIGHT / 4 + (options.indexOf(option) * 32));
            option.setDepth(1);
            option.setPinned(true);
        }

        q = new ArrayList<QuestionBank>();
        for (int i = 0; i < ShsGameInfo.FINAL_UNITS_COVERED.length(); i++){
            q.add(new QuestionBank(Integer.valueOf(ShsGameInfo.FINAL_UNITS_COVERED.substring(i, i+1))));
        }

        nextQuestion = true;
        answer = "";
        unit = "";
        questionDrawn = -1;
        scoreCounter = 0;
        totalQuestions = 0;
        correctlyAnswered = 0;

        // THIS IS AN EXAMPLE OF HOW TO
        // OUTPUT MESSAGES TO THE LOG
        ShsLog.write("Type in your answer using A, B, C, or D, or just use 1, 2, 3, or 4 on a keypad.");
        ShsLog.write("Most of these questions are from Ms. Broder :)");

    }

    public void updateOptions(ArrayList<String> updateStr){
        int index = 0;
        for (ShsText option : options){
            option.setText(QuestionBank.ANSWER_LETTERS.substring(index, index + 1) + ") " + updateStr.get(index));
            index++;
        }
    }

    public void updateAvg(){
        if (totalQuestions != 0){
            average.setText("Average: " + String.valueOf(Math.round(((double)correctlyAnswered / totalQuestions) * 100)) + "%");
        }
    }

    //= UPDATE =========================================//
    //--------------------------------------------------//
    //  This method is called roughly every sixteen     //
    //  milliseconds (60 FPS), and should contain all   //
    //  of your scene's logic.                          //
    //--------------------------------------------------//
    @Override
    public void update() {

        if (nextQuestion){
            int index = (int)(Math.random() * ShsGameInfo.FINAL_UNITS_COVERED.length());
            unit = ShsGameInfo.FINAL_UNITS_COVERED.substring(index, index + 1);
            unitName.setText("Unit " + unit);
            for (QuestionBank qb : q){
                if (qb.getUnitName() == Integer.valueOf(unit)){
                    questionDrawn = (int)(Math.random() * qb.getLength());
                    question = new TextContained(ShsGameInfo.SCREEN_WIDTH / 32, ShsGameInfo.SCREEN_HEIGHT / 14, ShsGameInfo.SCREEN_WIDTH * 2,qb.getQuestion(questionDrawn), "Cuprum-Regular", 32);
                    updateOptions(qb.getAnswerChoices(questionDrawn));
                    nextQuestion = false;
                }
            }
        }

        if (ShsKeyboard.isClicked(ShsKey.A) || ShsKeyboard.isClicked(ShsKey.NUM_1)) {
            answer = "A";
        }

        if (ShsKeyboard.isClicked(ShsKey.B) || ShsKeyboard.isClicked(ShsKey.NUM_2)) {
            answer = "B";
        }

        if (ShsKeyboard.isClicked(ShsKey.C) || ShsKeyboard.isClicked(ShsKey.NUM_3)) {
            answer = "C";
        }

        if (ShsKeyboard.isClicked(ShsKey.D) || ShsKeyboard.isClicked(ShsKey.NUM_4)) {
            answer = "D";
        }

        if (answer != "" && !nextQuestion){
            for (QuestionBank qb : q){
                if (qb.getUnitName() == Integer.valueOf(unit)){
                    if (qb.getRightAnswer(questionDrawn).equals(answer)){
                        scoreCounter += 100;
                        correctlyAnswered++;
                        score.setColor(25, 200, 25);
                        feedback.setText("");
                    }else{
                        scoreCounter -= 50;
                        score.setColor(200, 25, 25);
                        feedback.setText("CORRECT ANSWER FOR PREVIOUS QUESTION: " + qb.getFullRightAnswer(questionDrawn));
                    }
                    score.setText("Score: " + scoreCounter);
                    totalQuestions++;
                    try{
                        Thread.sleep(50);
                        nextQuestion = true;
                        answer = "";
                    }catch (InterruptedException e){
                        setNext(new TestScene());
                        setState(ShsSceneState.FADING_OUT);
                    }
                }

            }
        }

        updateAvg();

        // WHEN SWITCHING SCENES, SET THE STATE TO FADING
        // OUT, AND SET THE NEXT SCENE TO AN INSTANCE OF
        // WHATEVER SCENE SHOULD FOLLOW THIS ONE
        if (ShsKeyboard.isClicked(ShsKey.SPACE)) {
            setNext(new TestScene());
            setState(ShsSceneState.FADING_OUT);
        }

        // IF THE NEXT SCENE IS NULL, THE APP SHUTS DOWN
        if (ShsKeyboard.isClicked(ShsKey.ESCAPE)) {
            setNext(null);
            setState(ShsSceneState.FADING_OUT);
        }

    }


    //= DRAW ===========================================//
    //--------------------------------------------------//
    //  This method is called just after every update,  //
    //  and should contain only as much code as needed  //
    //  to trigger draw events in any sprites or text   //
    //  that the scene contains.                        //
    //--------------------------------------------------//
    @Override
    public void draw() {

        // AS LONG AS YOU'RE PROPERLY SETTING DEPTHS
        // FOR YOUR DRAWABLE OBJECTS, THE ORDER IN
        // WHICH THEY ARE DRAWN DOES *NOT* MATTER!
        unitName.draw();
        question.draw();
        score.draw();
        average.draw();
        feedback.draw();
        for (ShsText option : options){
            option.draw();
        }



    }


    //= CLEANUP ========================================//
    //--------------------------------------------------//
    //  This method is called when the scene has ended, //
    //  and is an appropriate place for handling any    //
    //  tasks which coincide with shutting down your    //
    //  scene (for example, saving data to a file or    //
    //  freeing up resources).                          //
    //--------------------------------------------------//
    @Override
    public void cleanup() {

        // IF YOU NEED TO DEREFERENCE OBJECTS, THIS IS
        // A GOOD SPOT TO DO SO!  GARBAGE COLLECTION IS
        // TRIGGERED BETWEEN SCENES TO RECLAIM RESOURCES
        unitName = null;
        question = null;
        score = null;
        average = null;
        feedback = null;
        options = null;
        // .
        // .
        // .
        // ETC.


        // PEACE OUT...
        ShsLog.write("Goodbye!");

    }

}


//= READY TO START MAKING YOUR OWN SCENES? =========================//
//------------------------------------------------------------------//
//  Add a new class to your project and make sure that it inherits  //
//  from ShsScene.  You can check line 9 in this file for an        //
//  example of what that looks like.                                //
//                                                                  //
//  Then, add the four basic methods outlined above - initialize,   //
//  update, draw, and cleanup.  You will write your own code in     //
//  these methods, but feel free to steal anything useful that you  //
//  find in this test scene!                                        //
//                                                                  //
//  Finally, go to the ShsGameInfo class and change line 39 so that //
//  it instantiates your new scene, rather than TestScene.  For     //
//  example, if your scene is called MainMenu, you would write:     //
//                                                                  //
//  public static final ShsScene STARTUP_SCENE = new MainMenu();    //
//                                                                  //
//  The next time you run your app, you'll no longer see this test  //
//  scene after the logo disappears.  You can always get it back    //
//  by changing line 39 in ShsGameInfo back to its original form:   //
//                                                                  //
//  public static final ShsScene STARTUP_SCENE = new TestScene();   //
//                                                                  //
//  That's about it.  Have fun developing apps with the ShsEngine!  //
//------------------------------------------------------------------//