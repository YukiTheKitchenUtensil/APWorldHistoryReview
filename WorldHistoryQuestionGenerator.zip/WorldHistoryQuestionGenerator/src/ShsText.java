import java.awt.*;
import java.io.File;
import java.io.IOException;

//= ShsText ============================================//
//------------------------------------------------------//
//  This class allows developers to display text on the //
//  screen, and provides options for loading custom     //
//  fonts, setting the font size, and adjusting         //
//  alignment.                                          //
//------------------------------------------------------//

public class ShsText extends ShsDrawable {

    //region ATTRIBUTES

    private String text;
    private Font font;
    private int size;
    private ShsTextAlignment alignment;
    private ShsVector offset;
    private Color color;

    static final String DEFAULT_FONT = "Cuprum-Regular"; // PLEASE SEE THE LICENSE AT THE BOTTOM OF THIS FILE!
    static final int DEFAULT_SIZE = 24;

    //endregion

    //region CONSTRUCTORS

    public ShsText() {
        this("", DEFAULT_FONT, DEFAULT_SIZE);
    }

    public ShsText(String font_name) { this("", font_name, DEFAULT_SIZE); }

    public ShsText(String font_name, int size) {
        this("", font_name, size);
    }

    public ShsText(String text, String font_name, int size) {
        setStartingValues(text, size);
        loadFont(font_name);
        offset.y = ShsPanel.graphics.getFontMetrics(font).getHeight()/2;
    }

    //endregion

    //region BASIC METHODS

    @Override
    public void internalDraw() {

        // ANTIALIASING
        if (ShsGameInfo.ANTIALIASING == ShsAntialias.TEXT_ONLY ||
                ShsGameInfo.ANTIALIASING == ShsAntialias.TEXT_AND_SPRITES) {
            ShsPanel.graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        }
        else {
            ShsPanel.graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        }

        ShsPanel.graphics.setFont(font);
        ShsPanel.graphics.setColor(color);
        ShsPanel.graphics.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));
        ShsPanel.graphics.drawString(text, (int)(getPositionX() - offset.x - (getPinned() ? 0 : -ShsGameInfo.SCREEN_WIDTH / 2.0 + ShsCamera.getOffsetX())), (int)(getPositionY() + offset.y - (getPinned() ? 0 : -ShsGameInfo.SCREEN_HEIGHT / 2.0 + ShsCamera.getOffsetY())));
    }

    //endregion

    //region INITIALIZATION METHODS

    private void setStartingValues(String text, int size) {
        this.text = text;
        this.size = size;
        setPosition(ShsVector.ZERO());
        this.alignment = ShsTextAlignment.LEFT;
        this.offset = ShsVector.ZERO();
        this.color = Color.BLACK;
    }


    private void loadFont(String font_name) {
        try {
            font = Font.createFont(Font.TRUETYPE_FONT, new File("src/Resources/Fonts/" + font_name + ".otf")).deriveFont((float)size);
        } catch (FontFormatException e) {
            font = ShsPanel.graphics.getFont().deriveFont((float)size);
            ShsLog.write(font_name + ".otf might not be a compatible font.");
        } catch (IOException e) {
            font = ShsPanel.graphics.getFont().deriveFont((float)size);
            ShsLog.write(font_name + ".otf does not exist in the Resources/Fonts/ folder.");
        }
    }

    //endregion

    //region ACCESSORS

    public String getText() {
        return text;
    }

    public int getSize() {
        return size;
    }

    public ShsTextAlignment getAlignment() {
        return alignment;
    }

    public Color getColor() {
        return color;
    }

    //endregion

    //region MUTATORS

    public void setText(String text) {
        if (this.text.equals(text))
            return;

        this.text = text;
        setAlignment(alignment);
    }


    public void setSize(int size) {
        if (size < 0)
            size = 0;

        this.size = size;
        font = font.deriveFont(Font.PLAIN, (float)size);

        setAlignment(alignment);
        offset.y = ShsPanel.graphics.getFontMetrics(font).getHeight()/2;
    }

    public void setAlignment(ShsTextAlignment alignment) {
        this.alignment = alignment;

        switch (this.alignment) {
            case LEFT:
                offset.x = 0;
                break;
            case CENTERED:
                offset.x = ShsPanel.graphics.getFontMetrics(font).stringWidth(text) / 2;
                break;
            case RIGHT:
                offset.x = ShsPanel.graphics.getFontMetrics(font).stringWidth(text);
                break;
        }
    }


    public void setColor(Color color) {
        this.color = color;
    }

    public void setColor(int r, int g, int b) { this.color = new Color(r,g,b); }

    //endregion

    //region OVERRIDE METHODS

    public String toString() {
        return this.text;
    }

    //endregion

}

// CUPRUM FONT LICENSE =========================================================================
// ---------------------------------------------------------------------------------------------
//
// Copyright (c) 2008-2012 by Jovanny Lemonad (jovanny.ru), with Reserved Font Name "Cuprum"
//
// This Font Software is licensed under the SIL Open Font License, Version 1.1.
// This license is copied below, and is also available with a FAQ at:
// http://scripts.sil.org/OFL
//
//
// -----------------------------------------------------------
// SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
// -----------------------------------------------------------
//
// PREAMBLE
// The goals of the Open Font License (OFL) are to stimulate worldwide
// development of collaborative font projects, to support the font creation
// efforts of academic and linguistic communities, and to provide a free and
// open framework in which fonts may be shared and improved in partnership
// with others.
//
// The OFL allows the licensed fonts to be used, studied, modified and
// redistributed freely as long as they are not sold by themselves. The
// fonts, including any derivative works, can be bundled, embedded,
// redistributed and/or sold with any software provided that any reserved
// names are not used by derivative works. The fonts and derivatives,
// however, cannot be released under any other type of license. The
// requirement for fonts to remain under this license does not apply
// to any document created using the fonts or their derivatives.
//
// DEFINITIONS
// "Font Software" refers to the set of files released by the Copyright
// Holder(s) under this license and clearly marked as such. This may
// include source files, build scripts and documentation.
//
// "Reserved Font Name" refers to any names specified as such after the
// copyright statement(s).
//
// "Original Version" refers to the collection of Font Software components as
// distributed by the Copyright Holder(s).
//
// "Modified Version" refers to any derivative made by adding to, deleting,
// or substituting -- in part or in whole -- any of the components of the
// Original Version, by changing formats or by porting the Font Software to a
// new environment.
//
// "Author" refers to any designer, engineer, programmer, technical
// writer or other person who contributed to the Font Software.
//
// PERMISSION & CONDITIONS
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of the Font Software, to use, study, copy, merge, embed, modify,
// redistribute, and sell modified and unmodified copies of the Font
// Software, subject to the following conditions:
//
// 1) Neither the Font Software nor any of its individual components,
// in Original or Modified Versions, may be sold by itself.
//
// 2) Original or Modified Versions of the Font Software may be bundled,
// redistributed and/or sold with any software, provided that each copy
// contains the above copyright notice and this license. These can be
// included either as stand-alone text files, human-readable headers or
// in the appropriate machine-readable metadata fields within text or
// binary files as long as those fields can be easily viewed by the user.
//
// 3) No Modified Version of the Font Software may use the Reserved Font
// Name(s) unless explicit written permission is granted by the corresponding
// Copyright Holder. This restriction only applies to the primary font name as
// presented to the users.
//
// 4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
// Software shall not be used to promote, endorse or advertise any
// Modified Version, except to acknowledge the contribution(s) of the
// Copyright Holder(s) and the Author(s) or with their explicit written
// permission.
//
// 5) The Font Software, modified or unmodified, in part or in whole,
// must be distributed entirely under this license, and must not be
// distributed under any other license. The requirement for fonts to
// remain under this license does not apply to any document created
// using the Font Software.
//
// TERMINATION
// This license becomes null and void if any of the above conditions are
// not met.
//
// DISCLAIMER
// THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
// OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
// COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
// OTHER DEALINGS IN THE FONT SOFTWARE.
//
// ---------------------------------------------------------------------------------------------