//= ShsTextAlignment ===================================//
//------------------------------------------------------//
//  This enumeration is utilized by the ShsText class   //
//  to properly align text on screen.                   //
//------------------------------------------------------//

public enum ShsTextAlignment {
    LEFT,
    CENTERED,
    RIGHT
}