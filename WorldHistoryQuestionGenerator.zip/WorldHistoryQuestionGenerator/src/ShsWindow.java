import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.*;

//= ShsWindow ==========================================//
//------------------------------------------------------//
//  This class acts like a main window for the          //
//  application.                                        //
//------------------------------------------------------//

public class ShsWindow extends JFrame implements WindowListener {

    //region CONSTRUCTOR

    public ShsWindow() {

        // ADD A PANEL TO THE WINDOW & RESIZE
        getContentPane().add(new ShsPanel());
        pack();

        // WINDOW SETTINGS
        setTitle(ShsGameInfo.TITLE);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(ShsGameInfo.RESIZABLE_WINDOW);
        setIconImage((new ImageIcon("src/Resources/Images/" + ShsGameInfo.ICON).getImage()));

        // SET POSITION (CENTER SCREEN)
        int x = Toolkit.getDefaultToolkit().getScreenSize().width / 2 - ShsGameInfo.SCREEN_WIDTH / 2;
        int y = Toolkit.getDefaultToolkit().getScreenSize().height / 2 - ShsGameInfo.SCREEN_HEIGHT / 2;
        setLocation(x,y);

        // SHOW IT
        setVisible(true);

        // LISTEN FOR WINDOW EVENTS
        addWindowListener(this);

    }

    //endregion

    //region WINDOWSLISTENER EVENTS
    public void windowIconified(WindowEvent e) {
        ShsTime.setPaused(true);
    }
    public void windowDeiconified(WindowEvent e) {
        ShsTime.setPaused(false);
    }
    public void windowOpened(WindowEvent e) { }
    public void windowClosing(WindowEvent e) {
        ShsLog.dump();
    }
    public void windowClosed(WindowEvent e) { }
    public void windowActivated(WindowEvent e) { }
    public void windowDeactivated(WindowEvent e) { }

    //endregion

}