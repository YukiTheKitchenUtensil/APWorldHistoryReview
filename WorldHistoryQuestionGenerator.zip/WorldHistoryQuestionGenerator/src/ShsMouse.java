import javax.swing.*;
import java.awt.*;

//= ShsMouse ===========================================//
//------------------------------------------------------//
//  This class allows the developer to get the position //
//  of the mouse on screen, as well as the states of    //
//  the left and right mouse buttons.                   //
//------------------------------------------------------//

public class ShsMouse {

    //region ATTRIBUTES

    private static ShsMouseButton leftButton;
    private static ShsMouseButton rightButton;
    private static boolean visible = true;

    //endregion

    //region ACCESSORS

    public static ShsVector getPosition() {
       return new ShsVector(getPositionX(), getPositionY());
    }

    public static int getPositionX() {
        return MouseInfo.getPointerInfo().getLocation().x - ShsPanel.panel.getLocationOnScreen().x;
    }

    public static int getPositionY() {
        return MouseInfo.getPointerInfo().getLocation().y - ShsPanel.panel.getLocationOnScreen().y;
    }

    public static ShsMouseButton getLeftButton() {
       if (leftButton == null) {
           leftButton = new ShsMouseButton();
       }
       return leftButton;
    }

    public static ShsMouseButton getRightButton() {
        if (rightButton == null) {
            rightButton = new ShsMouseButton();
        }
        return rightButton;
    }

    public static boolean getVisible() {
        return ShsMouse.visible;
    }

    //endregion

    //region MUTATORS

    public static void setVisible(boolean visible) {

        if (visible && !ShsMouse.visible) {
            ShsPanel.panel.setCursor(Cursor.getDefaultCursor());
        } else if (!visible && ShsMouse.visible){
            ShsPanel.panel.setCursor(ShsPanel.panel.getToolkit().createCustomCursor(new ImageIcon("src/Resources/Images/nix.png").getImage(), new Point(0, 0), ""));
        }

        ShsMouse.visible = visible;
    }

    //endregion

}