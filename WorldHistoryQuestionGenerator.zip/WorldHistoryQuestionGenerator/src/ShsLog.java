import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.PrintWriter;

//= ShsLog =============================================//
//------------------------------------------------------//
//  This class provides a way to output timestamped     //
//  messages to both the console and a log file.        //
//  NOTE: Setting DEBUGGING to false in the ShsGameInfo //
//  class will limit output to the log file only.       //
//------------------------------------------------------//

public class ShsLog {

    //region ATTRIBUTES

    private static ArrayList<String> log;

    //endregion

    //region BASIC METHODS

    public static void write(String message) {

        // INITIALIZE THE ARRAYLIST?
        if (log == null) {
            log = new ArrayList<String>();
        }

        // ADD THE MESSAGE TO THE ARRAYLIST
        log.add(LocalDateTime.now() + ": " + message);

        // BOUNCE?
        if (!ShsGameInfo.DEBUGGING) {
            return;
        }

        // OUTPUT THE MESSAGE W/ TIMESTAMP
        System.out.println(LocalDateTime.now() + ": " + message);
    }


    public static void dump() {

        // NO MESSAGES? BOUNCE.
        if (log == null) {
            return;
        }

        // PRINT THE CONTENTS OF THE LOG TO A FILE
        try {
            PrintWriter pw = new PrintWriter(new FileWriter("log.txt"));
            for (String str : log) {
                pw.println(str);
            }
            pw.close();
        } catch (IOException e) {

        }
    }

    //endregion

    //region WRITE OVERRIDES

    public static void write(int message) { write("" + message); }
    public static void write(double message) { write("" + message); }
    public static void write(float message) { write("" + message); }
    public static void write(char message) { write("" + message); }
    public static void write(boolean message) { write("" + message); }
    public static void write(short message) { write("" + message); }
    public static void write(long message) { write("" + message); }
    public static void write(byte message) { write("" + message); }
    public static void write(Object message) { write("" + message.toString()); }

    //endregion

}